#!/usr/bin/env node
/**
 * run-checks.mjs — run every check against one lesson.
 *
 *   node run-checks.mjs ../03-WORKED-EXAMPLES/type1-cause-and-effect/SS-3-2A-V3-BR.public.js
 *
 * Give it the PUBLIC pack. It finds the matching .server.js beside it, works out
 * which of the four shapes the lesson declares, and runs all three checks:
 *
 *   1. the shape validator  — is the structure right? (throws on the first problem)
 *   2. the quality audit    — is the writing right? (returns a list)
 *   3. crossCheckLesson     — do the two packs agree with each other? (returns a list)
 *
 * Exits 0 when clean, 1 when anything is wrong. A generator can call this in a
 * loop: generate → run → if it exits 1, read the problems, fix, run again.
 *
 * Every lesson you produce must exit 0 here BEFORE a human is asked to read it.
 * Exiting 0 does NOT mean the lesson is good — see HOW-TO-RUN-THE-CHECKS.md,
 * "What these checks cannot see."
 */

import { readdirSync } from "node:fs";
import { dirname, basename, resolve } from "node:path";
import { pathToFileURL } from "node:url";

import { validateSsThinkingShape, auditThinkingQuality } from "./schema/ssThinkingLesson.schema.js";
import { validateSsComparisonShape, auditComparisonQuality } from "./schema/ssComparisonLesson.schema.js";
import { validateSsPeopleShape, auditPeopleQuality } from "./schema/ssPeopleLesson.schema.js";
import { validateSsCategoryShape, auditCategoryQuality } from "./schema/ssCategoryLesson.schema.js";
import { crossCheckLesson } from "./schema/crossCheck.schema.js";

const SHAPES = {
  ssThinking:   { name: "Type 1 · cause and effect", validate: validateSsThinkingShape,   audit: auditThinkingQuality },
  ssComparison: { name: "Type 2 · comparison",       validate: validateSsComparisonShape, audit: auditComparisonQuality },
  ssPeople:     { name: "Type 3 · people",           validate: validateSsPeopleShape,     audit: auditPeopleQuality },
  ssCategory:   { name: "Type 4 · categories",       validate: validateSsCategoryShape,   audit: auditCategoryQuality },
};

// Where each practice mechanic keeps its answer key at runtime. Taken from what
// app/api/briefing/grade/route.js actually reads — note that reasonSort is the
// odd one out and uses `answers`, not `answerKey`.
const MECHANIC_KEY = {
  reasonSort: "answers",
  matchPairs: "answerKey",
  sequenceIt: "correctOrder",
  labelPicture: "answerKey",
  trueFalseReason: "answerKey",
};

/** The audit needs the answer key for the steps it checks. Which keys matter
 *  depends on the shape, so assemble it here rather than making every caller
 *  remember. */
function buildAnswers(pub, srv) {
  const a = {};
  for (const [mech, keyName] of Object.entries(MECHANIC_KEY)) {
    if ((pub.phases || []).includes(mech) && srv[mech]) a[mech] = srv[mech][keyName];
  }
  if (srv.clearance) a.clearance = srv.clearance.answers;
  if (srv.sideBySide) a.sideBySide = srv.sideBySide.rounds;
  if (srv.theDecision) a.theDecision = srv.theDecision.rounds;
  if (srv.wrongDesk) a.wrongDesk = srv.wrongDesk.rounds;
  if (srv.contrastSynthesis) a.contrastSynthesis = { sortAnswers: srv.contrastSynthesis.sortAnswers };
  if (srv.contributionSynthesis) a.contributionSynthesis = { sortAnswers: srv.contributionSynthesis.sortAnswers };
  if (srv.boundarySynthesis) a.boundarySynthesis = { sortAnswers: srv.boundarySynthesis.sortAnswers };
  return a;
}

const RED = "\x1b[31m", GREEN = "\x1b[32m", DIM = "\x1b[2m", BOLD = "\x1b[1m", OFF = "\x1b[0m";

async function main() {
  const arg = process.argv[2];
  if (!arg) {
    console.error("usage: node run-checks.mjs <path/to/LESSON.public.js>");
    console.error("       node run-checks.mjs --all        (every lesson in ../03-WORKED-EXAMPLES)");
    process.exit(2);
  }

  const targets = arg === "--all" ? findAll() : [resolve(arg)];
  let failed = 0;

  for (const pubPath of targets) {
    const srvPath = pubPath.replace(/\.public\.js$/, ".server.js");
    const { PUBLIC_BRIEFING: pub } = await import(pathToFileURL(pubPath).href);
    const { SERVER_BRIEFING: srv } = await import(pathToFileURL(srvPath).href);

    const shape = SHAPES[pub.shape];
    console.log(`\n${BOLD}${pub.id}${OFF}  ${DIM}${basename(pubPath)}${OFF}`);
    if (!shape) {
      console.log(`  ${RED}✗${OFF} unknown shape "${pub.shape}" — must be one of: ${Object.keys(SHAPES).join(", ")}`);
      failed += 1;
      continue;
    }
    console.log(`  ${DIM}${shape.name} · TEKS ${pub.teks}${OFF}`);

    let bad = 0;

    // 1. structure
    try {
      shape.validate(pub);
      console.log(`  ${GREEN}✓${OFF} shape`);
    } catch (e) {
      console.log(`  ${RED}✗${OFF} shape — ${e.message}`);
      bad += 1;
    }

    // 2. writing
    const answers = buildAnswers(pub, srv);
    const audit = shape.audit(pub, { answers });
    if (!audit.length) console.log(`  ${GREEN}✓${OFF} quality audit`);
    else {
      console.log(`  ${RED}✗${OFF} quality audit — ${audit.length} problem(s)`);
      audit.forEach((p) => console.log(`      · ${p}`));
      bad += audit.length;
    }

    // 3. the two packs against each other
    const cross = crossCheckLesson(pub, srv);
    if (!cross.length) console.log(`  ${GREEN}✓${OFF} cross-check`);
    else {
      console.log(`  ${RED}✗${OFF} cross-check — ${cross.length} problem(s)`);
      cross.forEach((p) => console.log(`      · ${p}`));
      bad += cross.length;
    }

    if (bad) failed += 1;
  }

  console.log("");
  if (failed) {
    console.log(`${RED}${failed} of ${targets.length} lesson(s) have problems.${OFF} Fix them and run again.`);
    process.exit(1);
  }
  console.log(`${GREEN}All ${targets.length} lesson(s) clean.${OFF} ${DIM}That means well-formed, not good — a human still reads it.${OFF}`);
}

function findAll() {
  const root = resolve(dirname(new URL(import.meta.url).pathname), "..", "03-WORKED-EXAMPLES");
  const out = [];
  for (const dir of readdirSync(root, { withFileTypes: true })) {
    if (!dir.isDirectory()) continue;
    for (const f of readdirSync(resolve(root, dir.name))) {
      if (f.endsWith(".public.js")) out.push(resolve(root, dir.name, f));
    }
  }
  return out.sort();
}

main().catch((e) => { console.error(e); process.exit(2); });
