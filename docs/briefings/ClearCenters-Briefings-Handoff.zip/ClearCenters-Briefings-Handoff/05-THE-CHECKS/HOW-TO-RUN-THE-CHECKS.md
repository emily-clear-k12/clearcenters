# How to run the checks, and what every message means

Three checks run against every lesson. All three must pass before a human is asked
to read it. **None of them can tell you whether the lesson is any good** — see the
last section, which is the most important one in this file.

---

## 1. Running them

```
cd 05-THE-CHECKS
node run-checks.mjs ../03-WORKED-EXAMPLES/type1-cause-and-effect/SS-3-2A-V3-BR.public.js
node run-checks.mjs --all
```

Give it the **public** pack. It finds the `.server.js` beside it, reads the `shape`
field to work out which of the four types it is, and runs everything. Exit code 0
means clean, 1 means problems, 2 means it couldn't run at all.

The loop to use when generating: **generate → run → if it exits 1, read the problems,
fix, run again.** Do not hand a lesson to a human until it exits 0.

Requires Node 18+. No dependencies, nothing to install.

### One gotcha that will waste your time

`schema/index.js` is written for Next.js and imports without file extensions
(`from "./mechanics.schema"`). Plain Node will not resolve those. **Do not import
`index.js` from a script** — import the individual schema files, which do use
extensions. `run-checks.mjs` already does this correctly; copy its imports.

---

## 2. The three checks

### Check 1 — the shape validator

`validateSsThinkingShape` / `validateSsComparisonShape` / `validateSsPeopleShape` /
`validateSsCategoryShape`, picked by the lesson's `shape` field.

Checks structure only: are the seven phases present and in order, does every phase
have a content block, are the required fields there, are the counts right. **It throws
on the first problem it finds**, so fix and re-run — there may be more behind it.

### Check 2 — the quality audit

`auditThinkingQuality` / `auditComparisonQuality` / `auditPeopleQuality` /
`auditCategoryQuality`. Returns a list rather than throwing, so you see everything at
once. Checks the writing: giveaways, reading load, answer-length tells, and the
per-type properties.

### Check 3 — the cross-check

`crossCheckLesson(publicPack, serverPack)`. The only check that reads both files. It
catches ids that exist in one pack and not the other — the single most likely failure
in generated work, and one that passes every other check, builds fine, and then breaks
silently in front of a child.

---

## 3. Every message, and what to do about it

### Structure problems (check 1)

| Message contains | What it means | Fix |
|---|---|---|
| `phases must be 7 entries` | Wrong number of phases. | Use exactly the seven your shape declares, in order. |
| `phases[N] must be "X"` | A phase is out of order or misnamed. | Match the order in the shape file exactly. |
| `missing content block lesson.X` | A phase is listed but has no content object. | Add `X: { … }` at the top level of the public pack. |
| `minutes should be 18-24` | The `minutes` field is out of range. | These are twenty-minute stations. Set 20 unless there's a reason. |
| `needs at least N` | Not enough beats, rounds, cards, options, items. | Add more. The minimum exists because below it the phase stops working. |
| `has no choice marked best` | The decision step has no correct answer. | Mark one `best: true`. **Type 3 is the exception** — see below. |
| `needs a whatIf` | A wrong option has no feedback. | Every distractor teaches. Add `whatIf` explaining what would have followed. |
| `bridge missing` (Type 1) | A beat doesn't link to the next. | Without it the beats shuffle, which is the original failure. Every beat but the last needs one. |
| `marks a decisionOption "best"` (Type 3) | You marked a right answer in the decision step. | Type 3's decision has **no** right answer. Use `actual: true` on what the person really did. |
| `must have exactly one decisionOption marked actual` | Zero or two `actual` flags. | Exactly one, always. |
| `lesson.rules needs at least 2` (Type 4) | No reach-rules declared. | Type 4's graded step names a **rule**, not a category. Without rules it's just a sort. |
| `boundaries needs at least 2` (Type 4) | Too few boundary cases. | A category's definition lives at its edge. Add items that genuinely sit between two categories. |

### Writing problems (check 2)

| Message contains | What it means | Fix |
|---|---|---|
| `gives its own answer away ("word" is the X bin's own wording)` | A sort clue contains a word from its own bin's label or definition. | **Reword the clue, don't delete it.** Say the same thing without that word. |
| `runs ~N student-facing words per screen (budget 110)` | Too much reading. | **Trim the prose, don't remove a question.** Cut adjectives and second clauses. This one fires constantly — write tight from the start. |
| `the correct option is the longest one` | Students pick long answers without reading. | Trim the correct one or pad the distractors so it isn't the unique longest. |
| `is answered verbatim by earlier lesson text` | A quiz question is given away by the teach. | Rewrite the question to ask about a new case, not the taught one. |
| `every sideBySide round blames the same cause` (Type 2) | All differences come down to one cause. | Vary them. A student who taps the same answer three times isn't reasoning. |
| `has no "both" item` (Type 2) | Nothing sorts as shared. | The standard's point is that the needs are shared and only the ways differ. At least one item must be "both". |
| `states its own cause in the setup` (Types 2, 4) | The answer is in the question. | Reword the setup so the student has to supply the connection. |
| `the real choice sits at the same position` (Type 3) | `actual` is always option 2. | Shuffle. Otherwise students find it by position. |
| `no round records what the decision cost` (Type 3) | Every choice worked out perfectly. | Add `cost` to each round. History where nobody paid for anything is hagiography. |
| `kinds … never named in the teach` (Type 3) | A declared kind is never the answer. | Give it a round, or drop it. |
| `categories that never appear as a wrong answer` (Type 4) | A category is only ever correct. | A category nobody is tempted to pick isn't being tested. Offer it as a plausible wrong route. |
| `has no option marked isNoChange` | The counterfactual has no "nothing changes" option. | Add one, as a **wrong** answer. It's how the student who thinks differences aren't caused reveals themselves. |

### Agreement problems (check 3)

These are almost always typos, and almost always fatal at runtime. Fix the id.

| Message contains | What it means |
|---|---|
| `id mismatch: public pack is X, server pack is Y` | You paired the wrong two files. |
| `has no answer key in the server pack` | A beat/round exists in public with no server entry. The graded step can never be graded. |
| `server pack has a key for X, which does not exist in the public pack` | The reverse — an orphan key. |
| `keys to reason/cause/kind/rule "X", which is not one of …` | The server names something the public pack doesn't offer. |
| `item "X" has no entry in the answer key` | A sort item is silently dropped from scoring; a student can pass without it. |
| `keys to bin "X", which does not exist` | Typo in a bin id. |
| `answer key is under "answerKey", but the grading route reads "answers"` | **Reason Sort only.** It is the one mechanic that uses `answers`. Every other mechanic uses `answerKey`. |
| `correctIndex N, outside its M options` | Index out of range — nothing can ever be right. |
| `has N wrongMessages for M options` | These are index-aligned. A short array means the last options fall back to generic copy. |
| `clearance item "X" has no entry in server answers` | The grader iterates the key, not the items — so this item is never scored and never reported. |
| `keepClaim item must key to null` | The teacher-read item has an answer key. It shouldn't. |
| `keepSelfContradicting … is also used as a correct ending` | One option can't be both the trap and a right answer. |
| `transfer has N reasons with two or more proofs` | **Important.** Exactly one reason may have two proofs. Two means the phase has two right answers and nobody will notice until a class argues about it. |
| `transfer has no "none" decoy spot` | The misconception the phase exists to catch can never come up. |
| `requireDeferredReason is on, but … leaves N deferred` | The grader only asks when exactly one real project is left unbuilt. With any other number the gate silently checks nothing. |
| `column "X" never receives an item` | A category with nothing in it teaches nothing. |

---

## 4. What these checks cannot see

**Read this before you trust a clean run.**

A lesson that exits 0 is *well-formed*. That is not the same as good. Here is the
proof, and it is worth internalising: the old `SS-3-2B-BR` — included in this package
under `04-BEFORE-AND-AFTER/` — trips only **two** of these checks. That lesson has
joke distractors ("toys, snacks, fame, naps, cartoons"), a Match Pairs phase solvable
by matching the word "school" to the word "Education", and a quiz question whose
answer is stated word-for-word three screens earlier. The checks see almost none of
it.

Specifically, these cannot be caught mechanically:

1. **Whether a causal chain actually holds.** You will produce three events that
   *sound* sequential and aren't. Nothing here will notice. Every Type 1 lesson needs
   a human read for this.
2. **Whether a distractor is a real misconception** or merely a plausible-sounding
   wrong answer. This is the difference between an item that tells a teacher who
   understood and one that doesn't.
3. **Whether a historical claim is true.** The no-giveaway rule is string matching,
   not meaning or fact. Verify every "this really happened" line against a real
   source and cite it in the file header, the way the worked examples do.
4. **Semantic giveaways.** A clue saying "chapel" gives away religious freedom and
   nothing will catch it, because "chapel" appears in neither the bin label nor its
   definition.
5. **Giveaways in three of the five mechanics.** The no-giveaway rule runs on
   `reasonSort` only. `matchPairs` and `labelPicture` can still hand over their own
   answers — which is exactly how the old 3.2B shipped. Check those by hand, every
   time, until the rule is extended.

**So: flag, don't hide.** When you are unsure whether a chain holds, whether a
distractor is real, or whether a claim is true, say so in the file header under a
clear heading. A flagged uncertainty costs a reviewer a minute. An unflagged one gets
taught to a class.
