# ClearCenters Briefings — Generation Handoff

**Everything needed to generate ClearCenters briefing lessons. Assembled Sept 14, 2026.
Self-contained: assume the reader knows nothing about this project.**

---

## What this is

**ClearCenters** is a Grades 3–5 curriculum product for Texas TEKS, built by Emily
Clear under the Crystal Instruction brand. **Briefings** are one engine inside it:
twenty-minute self-serve station lessons a student runs alone on a device, framed as
intelligence work for "HQ" with a guide character called S.A.M.

A briefing ships as **two files**:

- `<ID>.public.js` — everything the browser receives
- `<ID>.server.js` — the answer keys, which must never be imported by a client component

## What you are being asked to do

Generate briefing lessons for Texas Social Studies standards in Grades 3, 4 and 5,
one lesson per standard, using **four fixed lesson types**. Which type each standard
gets has already been decided — see `02-THE-TYPES/BRIEFINGS-ASSIGNMENT-TABLE.md`.
Do not choose types yourself.

Every lesson must pass three automated checks before a human reads it. The checks are
in this package and they run with plain Node, no install.

### Before you generate at volume — an open decision

The assignment table covers **135 lessons**. The project's earlier plan assumed about
thirty. That gap is real and **Emily has not yet decided** whether to build all 135,
bundle related standards down to roughly 90, or prioritise by classroom weight.
See §4 of the assignment table.

**Do not start a volume run until that is settled.** Generating everything and then
deciding to bundle throws work away, and every generated lesson costs human review
time whether it ships or not. Generating a handful to prove the pipeline is fine and
useful.

---

## Read in this order

| # | Read | Why |
|---|---|---|
| 1 | `01-WHY/BRIEFINGS-V3-MASTER-BRIEF.md` | Why these lessons look the way they do. It documents a previous version that looked fine and taught nothing, and the specific evidence for that. **Read §2 before writing a single line of content** — everything else is easy to copy and easy to fill with material that looks right and teaches nothing, which is exactly what happened twice before. |
| 2 | `04-BEFORE-AND-AFTER/BEFORE-AND-AFTER.md` | The same standard taught twice — the shipped version and the rebuild — with the six failures named line by line. Rules tell you what to do; this shows you what they're for. The most useful twenty minutes here. |
| 3 | `02-THE-TYPES/BRIEFINGS-LESSON-TYPES-DRAFT.md` | The four types: what each teach and synthesis do, and **§9, the rules that apply to every lesson**. You cannot build correctly without §9. |
| 4 | `02-THE-TYPES/BRIEFINGS-ASSIGNMENT-TABLE.md` | The work order. Every Grade 3–5 standard, its type, and notes on edge cases. |
| 5 | `03-WORKED-EXAMPLES/` | One complete, correct, passing lesson per type, with the reasoning for each decision written into the file headers. Copy these patterns. |
| 6 | `05-THE-CHECKS/HOW-TO-RUN-THE-CHECKS.md` | How to run the checks, what every error message means, and — most importantly — what they cannot see. |
| 7 | `06-PLAYER/PLAYER-INTEGRATION.md` | Only if you are wiring lessons into the app rather than writing content. |

---

## The four types in one table

| Type | Use when the standard asks… | The teach | The student names… |
|---|---|---|---|
| **1 · Cause and effect** | why something happened, what caused it, what followed | one place, three beats, each problem caused by the last solution | the **reason** |
| **2 · Comparison** | how two things differ | meet place A, **predict** place B, find out, explain the difference | the **cause of the difference** |
| **3 · People** | who did something and what it contributed | you're in their position, you choose, then you learn what they did | the **kind of contribution** |
| **4 · Categories** | which group a thing belongs to | a problem arrives at the wrong desk and it costs something | the **rule**, never the category |

### The structure all four share — the single most important thing here

Every type's teach is the same four beats, in the same order:

> **Show a situation → make the student commit before they are told → reveal what
> actually happened → make the student NAME the idea themselves.**

That last step is the graded one in all four types. What gets named is a level of
abstraction *above* what's on screen — which is why the student can carry it to a case
they have never seen.

This is the difference between these lessons and the ones they replace. In the old
version the label was handed to the student and they were asked to recognise it
afterwards. That is the failure. Do not hand over the label.

---

## The rules that matter most

The full list is §9 of the types document. These are the ones most often broken:

1. **No typing, anywhere.** Third graders type about five words a minute. Every
   response is a tap — but options must **combine into claims that can be false**,
   rather than matching one to one. Three reasons × six pieces of evidence is eighteen
   sentences, twelve of them untrue; that's a reasoning task with the same number of
   taps as a matching task.
2. **No distractor is a joke.** Every wrong option is a mistake a student actually
   makes, and its feedback teaches rather than marks. If a student who learned nothing
   can eliminate their way to the answer, the item cannot tell a teacher who
   understood — which is the only thing an item is for.
3. **Wrong answers should be worth getting wrong.** A student who picks a distractor
   should come away with something the correct answer alone wouldn't have taught them.
4. **Something in every lesson has no right answer** and goes to the teacher. The
   opinion is never marked; only whether the sentence holds together is checked.
5. **A clue never contains its own answer.** Mechanically enforced for one mechanic,
   your responsibility for the rest.
6. **Nothing is pre-answered.** If earlier text states the answer to a later question,
   that question is decoration.
7. **Stay inside the reading budget** — 110 student-facing words per screen. This
   fires constantly. Write tight from the start.
8. **The correct option is never the longest one.**
9. **No confetti, no celebration bursts.** Explicitly rejected. There is a validator
   that throws if a lesson adds `engagement.celebrationBurst`. The footprint progress
   trail and the hidden S.A.M. bonus after Clearance are kept.
10. **If a field isn't rendered, either wire it or delete it.** Shipping content a
    student cannot see is one of the two failure modes this rebuild exists to stop.

---

## When you are not sure: flag, don't hide

The checks catch structure and sloppiness. They cannot catch **meaning**. Four things
are permanently your judgment and a human's, never the checker's:

- whether a causal chain actually holds, or merely sounds like it does
- whether a distractor is a real misconception or just a plausible wrong answer
- whether a historical claim is true
- whether a category boundary you drew is the real one

**Say so in the file header when you are unsure.** Use a clear heading, the way the
worked examples do. A flagged uncertainty costs a reviewer one minute. An unflagged
one gets taught to a class of eight-year-olds.

### On historical claims specifically

These lessons state things about real people to children. Verify every "this really
happened" line against a real source, and cite the source in the file header — see
`03-WORKED-EXAMPLES/type3-people/SS-3-1B-V3-BR.public.js`, which does exactly this.

Popular classroom material is often wrong. A worked example in this package
deliberately **excludes** the widely-repeated claim that Benjamin Banneker reproduced
L'Enfant's plan for Washington from memory: it is disputed, probably a myth, and it
appears in a great deal of published teaching material. Do not reintroduce it.

Some standards describe real harm to real people — 5.4D (slavery and the causes of the
Civil War), 5.4E (Reconstruction and the 13th/14th/15th Amendments), 5.11B (the
plantation system), 4.4D (effects on American Indian life), 5.4F. They are in the
TEKS and they get taught. Write them carefully, flag every one for review, and do not
soften them into something tidy.

---

## What's in each folder

```
README.md                  ← you are here
package.json               ← marks the package as ESM so the checks run

01-WHY/
  BRIEFINGS-V3-MASTER-BRIEF.md      why this rebuild exists; the critique that drove it

02-THE-TYPES/
  BRIEFINGS-LESSON-TYPES-DRAFT.md   the four types, and §9 the rules for every lesson
  BRIEFINGS-ASSIGNMENT-TABLE.md     every Grade 3-5 standard → its type. The work order.

03-WORKED-EXAMPLES/                 one complete passing lesson per type
  type1-cause-and-effect/  SS-3-2A-V3-BR   "Why Communities Form"       TEKS 3.2A
  type2-comparison/        SS-3-2B-V3-BR   "Two Towns, Five Needs"      TEKS 3.2B
  type3-people/            SS-3-1B-V3-BR   "Three Ways to Build a Town" TEKS 3.1B
  type4-categories/        SS-3-7C-V3-BR   "The Wrong Desk"             TEKS 3.7C

04-BEFORE-AND-AFTER/
  BEFORE-AND-AFTER.md               the same standard taught twice, failures named
  OLD-SS-3-2B-BR.public/.server.js  the shipped version being replaced

05-THE-CHECKS/
  HOW-TO-RUN-THE-CHECKS.md          every error message and what to do about it
  run-checks.mjs                    runnable: node run-checks.mjs <lesson>.public.js
  schema/                           the shape contracts and the checks themselves

06-PLAYER/
  PLAYER-INTEGRATION.md             what's wired, what isn't, what wiring costs
  index.public.js / index.server.js the registries a finished lesson gets added to
```

### Try the checks first

```
cd 05-THE-CHECKS
node run-checks.mjs --all
```

All four worked examples should come back clean. If they don't, something is wrong
with the package rather than with them — say so rather than working around it.

---

## The state of things, honestly

**Done:** four lesson types designed and proven, one baseline lesson each, the shape
contracts, the quality audits, the cross-check, and every Grade 3–5 standard assigned
a type.

**Not done, and worth knowing:**

- **None of the four new lessons has ever been run in a browser.** They are verified
  by build, audit and hand-tracing only. Nobody has clicked through one.
- **Three of the four are not wired into the player** and none are assignable.
  See `06-PLAYER/`.
- **No "hub" lesson exists.** Type 1 has two flavours — chain (A caused B caused C)
  and hub (one thing changed many things). Ten standards are marked `T1-hub` in the
  assignment table and none has been built. The first one needs a human read before
  the rest follow.
- **The no-giveaway rule only runs on one of the five practice mechanics.**
  `matchPairs` and `labelPicture` can still smuggle their own answers. Check those by
  hand until it's extended.
- **The 135-vs-30 scope question is open.** See the top of this file.
- **No art exists** for the newer lessons. Phases that expect images run as word chips
  instead, which works but is weaker. Every lesson's header lists the art it needs.

---

## Who decides what

**Emily is the author of record.** She is a curriculum developer with about ten years
of classroom teaching and no coding background. She makes the pedagogical calls and
they are usually right. Explain things in plain language.

The standing convention on this project: **Claude drafts, Emily reviews, her colleague
approves.** Nothing is classroom-ready because it passed a checker. A clean run means
well-formed. A person still has to decide it is good.
