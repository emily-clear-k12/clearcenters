# The same standard, twice

Two lessons in this folder and the one beside it teach **TEKS 3.2B** — *compare how
the local community and other communities meet needs for government, education,
communication, transportation, and recreation.*

- **Before:** `OLD-SS-3-2B-BR.public.js` / `.server.js` — in this folder. Shipped, and
  still live.
- **After:** `../03-WORKED-EXAMPLES/type2-comparison/SS-3-2B-V3-BR.public.js` — the
  Type 2 worked example.

Read them side by side before you generate anything. Rules tell you what to do; a
matched pair shows you what the rules are *for*. This is the most useful twenty
minutes in the package.

**The important thing about the old one: it does not look bad.** It has a story, a
worked example, vocabulary, a practice phase, a quiz, and a friendly guide character.
It reads fine. It passes almost every mechanical check. That is exactly the problem —
a lesson can have all the parts and still ask nothing of a student.

---

## The six failures, with the lines that cause them

### 1. It asserts the standard instead of teaching it

The big idea of 3.2B is *same need, different way.* The old lesson simply says so, on
four consecutive screens:

- Field Brief page "Idea": *"Two towns can take care of the **same need** in
  **different ways**."*
- Page "Worked example": *"That is still **education**. Same need. Different way."*
- The SAM check on that page: *"Walking and the bus — same need or different needs?"*
- `learningTarget`: *"Different towns can meet the **same need** in **different
  ways**."*

By the time a student is asked anything, they have been told the answer four times.
Repetition is not instruction.

**What the rebuild does:** the student meets Maple Crossing, then **predicts** what
Cloudreach does before being told, then names **why** the two differ. The idea is
something they arrive at, not something they are handed. Nobody says "same need,
different way" until the student has already demonstrated it three times.

### 2. A quiz question is answered word-for-word by the teach

Old `clearance` item `c2`:

> *"Kids walk to school in Maple Crossing. Kids ride a bus in Cloudreach. Same need?"*

Old Field Brief page `worked`, three screens earlier:

> *"Kids in Maple Crossing **walk** to a little school. Kids in Cloudreach **ride a
> bus**. That is still **education**."*

It is the same sentence. The question measures whether the student was awake, not
whether they understood.

**Note that the audit does NOT catch this.** Its pre-answered check is exact
substring matching, and the wording differs just enough. This is a human-review item,
and it is the reason the "flag, don't hide" rule exists.

### 3. The practice phase is solvable by keyword

Old `matchPairs`:

| Left | Right |
|---|---|
| Education | "Walk to a small **school** vs. ride a bus to a bigger one" |
| Transportation | "A wagon **road** vs. a river ferry" |
| Recreation | "Splash at the creek **park** vs. swim at the rec center" |

Match "school" to "Education". No understanding required. A student who knows nothing
about communities scores five out of five.

**What the rebuild does:** seven clues, none of which contain a word from their own
category's label or definition, mechanically enforced. *"The ferryman waits for the
seven o'clock crowd"* is transportation, and you have to know what transportation
means to file it.

**Warning:** the no-giveaway rule only runs on `reasonSort`. This exact failure in
`matchPairs` would still ship today. Check that mechanic by hand.

### 4. The distractors are jokes

- `opsChoice` project: *"Giant welcome statue so visitors remember us"*
- `clearance` c1 option b: *"toys, snacks, fame, naps, cartoons"*
- Hidden bonus line about a duck pond

A student who learned nothing eliminates their way to the answer. An item whose wrong
answers are obviously wrong cannot tell a teacher who understood — which is the only
thing an item is for.

**What the rebuild does:** every distractor is a mistake a third grader actually
makes. *"A small town doesn't need all five"* is a real belief. *"The bigger town
takes care of more of them"* is a real belief. Both are wrong, both are tempting, and
each one's feedback teaches something.

### 5. The apply phase has no wrong answer

Old `opsChoice`: three real projects plus the statue, pick two, and the server accepts
**any two of the three real ones**. There is nothing to defend, which is why it never
felt like a decision.

**What the rebuild does:** three real needs, three townspeople who each want a
different one, all three right, and only two can be built. Somebody is always going to
be right and still have to wait — and the student is asked whose warning came true.

### 6. Nothing asks *why*

This is the deepest one. Across the entire old lesson, no question asks why two towns
differ. It notices differences and stops. Noticing that two things differ is not
thinking; explaining what caused the difference is.

**What the rebuild does:** naming the cause is the graded step in every round, and the
three rounds have three *different* causes — how many people, what the land does, what
was already there. A student who taps the same cause every time gets two wrong. The
synthesis then removes the cause — *somebody builds a bridge; which difference goes
away?* — which is the question that separates a student who memorised the differences
from one who understands them.

---

## What the checks said about each

| | Old 3.2B | New 3.2B |
|---|---|---|
| Shape validator | *(different shape — not comparable)* | pass |
| Quality audit | **2 problems** | **0 problems** |
| Cross-check | *(not run — predates it)* | **0 problems** |

The two problems the audit found in the old lesson were both reading load — its Field
Brief runs about **337 student-facing words on one screen** against a budget of 110.
That is the number behind "it's a lot of reading."

**It caught none of the six failures above.** Sit with that before you trust a clean
run on your own output.

---

## The one-line version

> The old lesson has every part a lesson should have, passes nearly every check, and
> asks a student to do nothing but recognise a sentence it already told them four
> times.

Your job is to produce the other kind.
