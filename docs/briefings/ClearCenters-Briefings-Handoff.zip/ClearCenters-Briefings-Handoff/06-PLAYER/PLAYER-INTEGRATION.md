# Player integration — what exists, what still needs wiring

**Read this if you are wiring lessons into the app. If you are generating lesson
content, you can skip it — but read the last section, because it explains why a
finished lesson is not yet a usable one.**

---

## The state of things, as of Sept 14 2026

Four lesson types exist, with one Grade 3 baseline lesson each. **None of the four
new lessons are wired into the player, and none are assignable.** They are content
files sitting in `lib/briefings/` that nothing imports yet.

That was deliberate: the shapes were proven and reviewed before spending effort on
plumbing that would have to change if a shape changed.

| Type | Lesson | Content | Schema | Player | Grading | Registry | Migration |
|---|---|---|---|---|---|---|---|
| 1 · cause and effect | `SS-3-2A-V3-BR` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ written |
| 2 · comparison | `SS-3-2B-V3-BR` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| 3 · people | `SS-3-1B-V3-BR` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| 4 · categories | `SS-3-7C-V3-BR` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

Type 1 is fully wired and was verified by `next build`, the audit and hand-tracing.
**It has still never been clicked through in a browser** — the sandbox has placeholder
Supabase credentials. Do that before any of this reaches students.

---

## What wiring a new type costs

Less than it looks. **Four of the seven phases are identical across all four types** —
`openingFrame`, `opsChoice`, `transfer` and `clearance` are already built, already
render, and already grade. Only the teach and the synthesis differ.

So each new type needs exactly four things:

### 1. Two React components in `app/briefing/[assignmentId]/BriefingClient.js`

| Type | Components to add |
|---|---|
| 2 · comparison | `SideBySide`, `ContrastSynthesis` |
| 3 · people | `TheDecision`, `ContributionSynthesis` |
| 4 · categories | `WrongDesk`, `BoundarySynthesis` |

Copy the existing `StoryTeach` and `Synthesis` components as the starting point —
they already handle the reveal-by-step rhythm every type uses.

Then in the same file:

- add the new phase ids to `PHASE_LABELS`
- add a state slice for each in `migratePhaseState(saved)` — every phase gets an
  unconditional slice, so a lesson can use any subset without extra migration code
- add the dispatch near the bottom: `if (phaseId === "sideBySide") body = <SideBySide … />`

`PHASES` is computed per briefing from `briefing.phases`, so nothing else needs to
change to make a new phase list work.

### 2. Two grading branches in `app/api/briefing/grade/route.js`

One `if (phase === "…")` branch per new phase. Follow the `storyTeach` and `synthesis`
branches — the response shape is `{ pass, softFail, message }` and wrong answers are
soft fails with teaching feedback, never hard errors.

### 3. Two lines in the registries

`lib/briefings/index.public.js` and `index.server.js` — an import and a REGISTRY entry
each. Both files are in this folder for reference.

### 4. A migration

Copy `add_briefings_ss_3_2a_v3_br_migration.sql`. Without it the lesson never appears
on the teacher's assign screen, however correct the code is.

---

## Three specific things that will bite you

**1. The decision step in Type 3 has no right answer.** `theDecision`'s options carry
`actual: true` on what the person really did, and **no** `best` flag. The component
must not render a right/wrong state for that step — it tags the student's pick
neutrally, then reveals the real one as a separate, differently-styled tag. Marking it
correct would break the whole point of the type. The published prototype shows the
intended treatment.

**2. Reason Sort's answer key is called `answers`, not `answerKey`.** Every other
mechanic uses `answerKey`. This is a genuine historical inconsistency — the
documentation in `mechanics.schema.js` said `answerKey` for months while
`route.js` read `answers`, which would have marked every clue wrong in any lesson
written from the docs. The docs are fixed and the cross-check now catches it, but know
it exists.

**3. `schema/index.js` imports without file extensions.** That's the Next.js
convention and it works in the app, but plain `node` cannot resolve it. Any standalone
script must import the individual schema files directly. `05-THE-CHECKS/run-checks.mjs`
does this correctly.

---

## Two bugs already found and fixed — don't reintroduce them

- **Ops Choice's continue button was hardcoded** to `goToPhase("evidenceDrop")`, which
  dead-ends any lesson whose next phase isn't Evidence Drop. It is `goNext()` now.
  Every new type depends on that fix.
- **`projects[].improves` was authored in every pack and rendered nowhere** for
  months. It's on the THIS YEAR board now. The general rule: if a field isn't
  rendered, either wire it or delete it. Shipping content a student cannot see is one
  of the two failure modes this whole rebuild exists to stop.

---

## Deploying, in this project specifically

Writing files into the repo folder is **not** deploying. The live site runs whatever
was last pushed to `main` on GitHub, and Vercel builds from that. A lesson can be
complete, correct, wired and migrated and still not exist for students until somebody
commits and pushes.

The order matters when both a code change and a SQL change are involved: **run the SQL
first.** Code that expects a column or table that isn't there yet breaks the page;
SQL that's run before the code that uses it just sits there harmlessly.
