# CI2.0 (Crystal Instruction 2.0) — Start Here

Handoff package, created September 16, 2026. It lets a new chat, or a different AI, pick up exactly where this work left off.

**How to use it:** attach this whole folder, or at least this file plus files 01 and 02, and paste the prompt from the "Resume prompt" section at the bottom.

## What's in this package

| File | What it is |
| --- | --- |
| `00_START_HERE.md` | This summary: context, decisions, current technical state, next steps |
| `01_CI2.0_Foundation_Brainstorm.md` (+ `.pdf`) | The full product design: every feature and decision |
| `02_CI2.0_Build_Plan.md` (+ `.pdf`) | The six-phase build plan, first steps and open decisions |
| `03_CI2.0_Sandbox_Setup_Guide.md` | Click-by-click guide for the sandbox (already completed) |
| `sandbox_code/` | Copies of the code files added or changed for the sandbox (the real ones live in the repo) |

Live versions of files 01 and 02 are Claude Docs in Emily's account:

- [Crystal Instruction 2.0 (CI2.0) — Foundation Brainstorm](https://claude.ai/code/artifact/4a132c38-f266-4527-813a-1166c7d6174b)
- [CI2.0 Build Plan](https://claude.ai/code/artifact/49021b35-c539-430f-841f-f5757a38cc2e)

---

## Who and what

- **Emily** is a curriculum developer at an educational publishing company, with about ten years of classroom teaching experience. She has **no coding background**. She works through GitHub Desktop, Vercel and Supabase by clicking, and needs plain-language, step-by-step instructions, one step at a time when things get confusing. Screenshots are her usual way of showing progress.
- **Crystal Instruction** (cs.cleark12.com) is the product family: ClearLessons, ClearSheets, ClearCenters, CrystalQuest, ClassCade Showdown, CrystalChecks, T-TESS / Teacher Observations and reports. Today these are separate sites.
- **CI2.0** is what the ClearCenters site (Grades 3–5, currently Texas TEKS) is becoming: **a curriculum platform with a built-in teacher assistant, not an empty LMS.** One site and one login for the whole product line, for teachers, students, families and admins. It works alongside districts' existing systems.
- **Guiding principle:** a huge build behind the scenes so the product is very easy to use. Most features run automatically, and the design stays calm, modern and self-explanatory without being condescending.

## Naming and voice rules

- The end-of-unit tests are called **CrystalChecks**. The earlier name is retired; always use CrystalChecks.
- **SAM** is the helper character for students and also the teacher's assistant and secretary.
- **Voice everywhere:** positive and honest. Never pretend things are perfect, never negative; always "here's what we can do to make this better or help this student." Use "not yet" language.

## Key decisions so far

**Delivery modes**

- ClearLessons: whole group, teacher-led.
- ClassCade Showdown: whole-group review.
- ClearSheets, ClearCenters, CrystalQuest: individually paced and assigned.

**Teacher side**

- The **Today** dashboard is the main screen: the day's agenda fills in automatically, with click-to-project thumbnails.
- **This Week** planning page with "hands-off levels." Each level is explained during setup, the teacher picks one, and she can switch anytime.
- **Weekly Routines** start personal, with an option to share with the team.
- **Lesson plans are generated automatically** using the Crystal Instruction default template, an uploaded district template, or custom columns.
- **Grading:** a built-in gradebook with PDF and spreadsheet export, and Skyward sync later through OneRoster.
- **Class Glows & Grows** one-pager for PLC meetings.
- **Student Profile** with a living plan and an automatic log of supports already provided.
- **Accommodations Autopilot and Tracker:** tracks how often a support was provided, how often it was used, and results with versus without it. Includes trial supports and the Strategy Backpack (an accommodation the teacher can grant to anyone).
- **Teacher phone companion app** is a **launch requirement**: agenda, notes, Quick Clips lesson feedback during duty.

**Students**

- **Choice setting** per class (mapped day or choice board), with a per-student override.
- **My Day** shows Now / Next / Later.
- **Confidence Check** on every submission.
- **Reflection check-in** at the end of each unit or every 30 days, not on every activity.
- **Home access:**
  - Home or school is detected automatically from the school network and school hours, with no button and no location services.
  - At home, students choose: finish what you started, at-home missions, or free practice.
  - The teacher controls what's available at home. Screen time at home is the parents' decision.
- **Automatic stamp on every submission (teacher-only):** when, where (home or school), active time, number of sittings and time per question. Students never see it.

**Families**

- Separate family login; progress only (average percentage and missing work).
- Full two-way messaging with quiet hours and automatic translation.
- **Families never see accommodations.**
- Weekly family newsletter (auto-generated, teacher-approved) with a Real-World Snap home activity.

**Admins and districts**

- **Coaches never see evaluations.**
- Evaluation evidence can be pulled automatically, with the teacher's final approval.
- District common assessments (for example, 9-week tests) can be pushed only by permitted accounts.
- **Usage data is shown as campus totals only, never by teacher name** (avoids "gotcha" moments).
- T-TESS comes first, built as a plug-in so other states' rubrics can be added.

**Scale**

- **All 50 states:** content is tagged to internal skills, and each state's standards are matched to those skills. **Georgia and Ohio come next after Texas.**
- **Languages:** built for translation from day one; Spanish first; bilingual supports throughout.
- **AI cost:** most "smart" features are rules on data or content written ahead of time; AI calls are batched, cached and capped.

**Set aside:** digital citizenship (separate SEL work is underway). **One day:** offline mode, Clear Adventures (outdoor and family learning projects), and a true App Store app.

---

## Current technical state (end of this session)

**Tech stack:** Next.js 14 site on Vercel (Hobby plan), Supabase database and logins (Free plan), and the Anthropic API for SAM.

**GitHub repo:** `github.com/emily-clear-k12/clearcenters`. Emily's local copy is `C:\Users\emben\OneDrive\Desktop\clearcenters`, managed with GitHub Desktop.

| | Live site | CI2.0 sandbox |
| --- | --- | --- |
| Git branch | `main` | `ci2-sandbox` (published) |
| Vercel environment | Production | Preview |
| Supabase project | `clearcenters` (id `ngdofwqukzovecjdyrbt`) | `clearcenters-sandbox` (id `vjsmhptbwuhguxyyziab`) |
| Data | Real | Structure and content copied from live (587 cases, 1,432 words, planets, badges, shop, briefings); **no teachers, students or student work** |
| Yellow A/B bar | Never shown | Shown on every page |

**How the sandbox stays separate (already built, tested and deployed):**

- `NEXT_PUBLIC_SANDBOX=true` is set **only for Vercel Preview**.
- When it's on, `lib/supabaseClient.js` and `lib/supabaseAdmin.js` use the sandbox settings, which are Preview-only in Vercel:
  - `NEXT_PUBLIC_SANDBOX_SUPABASE_URL`
  - `NEXT_PUBLIC_SANDBOX_SUPABASE_ANON_KEY`
  - `SANDBOX_SUPABASE_SERVICE_ROLE_KEY`
- If the sandbox settings are missing, the build **stops with an error** instead of falling back to live data. The live settings (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`) were left untouched.
- `components/SandboxBar.js` shows the yellow **A · Current site | B · CI2.0** bar. The `A_TO_B` map in that file pairs current pages with CI2.0 pages; add a line whenever a new CI2.0 page is built.
- **All CI2.0 pages live under `/v2`.** `app/v2/layout.js` returns 404 unless sandbox mode is on, so they can never appear on the live site.
- Placeholder pages exist at `/v2` (CI2.0 home), `/v2/teacher` (This Week) and `/v2/student` (My Day).
- The sandbox deployed successfully and was confirmed working. Emily bookmarked the branch link (the Vercel address containing `git-ci2-sandbox`).

**Does the repo or folder change?** No. Same repo, same local folder. In GitHub Desktop:

- **CI2.0 work:** switch **Current branch** to `ci2-sandbox`.
- **Fixes to the live site:** switch to `main`.
- **Always check the branch before committing.**
- **Never merge `ci2-sandbox` into `main`** without a deliberate decision.

**Connections Emily has set up for Claude:** Supabase (can run queries, check tables and create projects) and Vercel (connected, but it returned "forbidden" for the ClearCenters project, so deployment checks currently go through Emily's screenshots).

**Supabase SQL Editor tip:** it misreads semicolons and quotes inside long data strings. Large data loads worked only after base64-encoding the data (`convert_from(decode('…','base64'),'UTF8')::json`). Prefer running changes directly through the Supabase connection where possible.

**Known issues to raise with Emily (not yet fixed):**

- **Live database security warnings** (the sandbox copied them):
  - Some `SECURITY DEFINER` functions can be called without logging in: `grant_sam_skin`, `send_sam_shoutout`, `signal_ops_advance_session`, `signal_ops_submit_event`, `log_crystal_points_change`.
  - Six functions have no fixed `search_path`.
  - 16 tables have row-level security on but no policies (the site reaches them through the server key).
  - Recommended: tighten these on the live site soon.
- **Student PINs** are stored as plain text (noted in the original schema as a pilot shortcut).
- **`lib/devFlags.js`** has `DEV_FORCE_UNLOCK_ALL = true` on `main`. The comment says not to ship it as true, and it's currently live.

**Never share or paste secret keys (service role keys) in chat.**

---

## Open questions

- **Team data sharing:** what feels right to share with a team or in a meeting, and what stays private to the teacher and her admin? (Draft: the teacher controls a share view; anonymized, class-level by default; no teacher rankings.)
- **Gradebooks and district logins after Skyward:** likely driven by what Georgia and Ohio districts use.
- **Build decisions:** who builds it (Emily with Claude, plus likely a professional developer for district logins, gradebook sync and security review), target date for the Texas pilot, pilot scope (all four subjects, or Science and Social Studies first), and budget.

## Next steps

1. Pick the first real CI2.0 piece to build in the sandbox (**B**): the teacher's **This Week** page or the student's **My Day**.
2. Build plan, Phase 0 foundation work:
   - content audit
   - roles and permissions blueprint
   - Crystal skill map, matching TEKS first
   - content tags and the submission stamp
   - review which parts of today's site carry over
   - recruit pilot teachers
3. Still-undesigned topics: the content team's workflow (tagging, standards matching, translations), and a deeper pass on the unit-start flow and acting on data.
4. Fix the live-site issues listed above when Emily is ready.

---

## Resume prompt

Paste this into a new chat, along with this folder:

> I'm Emily. I'm building CI2.0 (Crystal Instruction 2.0), a curriculum platform with a built-in teacher assistant that's replacing my ClearCenters site. The attached handoff package has everything we've decided so far: start with 00_START_HERE.md, then the Foundation Brainstorm and Build Plan. I don't code, so please give me plain-language, click-by-click steps. We already have a working sandbox (branch `ci2-sandbox`, its own Supabase database, and the yellow A/B bar). Next, I'd like to [build the teacher This Week page / build the student My Day page / work on ___].
