// Registry of Signal Check SERVER-ONLY case content (grading rubrics).
// Never import this from a client component.
//
// Standards below are verified against Emily's official Texas TEKS PDFs —
// see lib/cases/TEKS_STANDARDS.md.

import { SERVER_CASE as CASE_3_6A_SC } from "./3-6A-SC.server";
import { SERVER_CASE as CASE_4_10B_SC } from "./4-10B-SC.server";
import { SERVER_CASE as CASE_5_13B_SC } from "./5-13B-SC.server";
import { SERVER_CASE as CASE_SS_3_6A_SC } from "./SS-3-6A-SC.server";
import { SERVER_CASE as CASE_SS_4_3A_SC } from "./SS-4-3A-SC.server";
import { SERVER_CASE as CASE_SS_5_4C_SC } from "./SS-5-4C-SC.server";
import { SERVER_CASE as CASE_3_10A_SC } from "./3-10A-SC.server";
import { SERVER_CASE as CASE_3_10B_SC } from "./3-10B-SC.server";
import { SERVER_CASE as CASE_3_10C_SC } from "./3-10C-SC.server";
import { SERVER_CASE as CASE_3_11B_SC } from "./3-11B-SC.server";
import { SERVER_CASE as CASE_3_12A_SC } from "./3-12A-SC.server";
import { SERVER_CASE as CASE_3_12B_SC } from "./3-12B-SC.server";
import { SERVER_CASE as CASE_3_12C_SC } from "./3-12C-SC.server";
import { SERVER_CASE as CASE_3_12D_SC } from "./3-12D-SC.server";
import { SERVER_CASE as CASE_3_6B_SC } from "./3-6B-SC.server";
import { SERVER_CASE as CASE_3_6C_SC } from "./3-6C-SC.server";
import { SERVER_CASE as CASE_3_6A_SC_WI } from "./3-6A-SC-WI.server";
import { SERVER_CASE as CASE_3_6A_SC_TH } from "./3-6A-SC-TH.server";
import { SERVER_CASE as CASE_3_6B_SC_WI } from "./3-6B-SC-WI.server";
import { SERVER_CASE as CASE_3_6B_SC_TH } from "./3-6B-SC-TH.server";
import { SERVER_CASE as CASE_3_6C_SC_WI } from "./3-6C-SC-WI.server";
import { SERVER_CASE as CASE_3_6C_SC_TH } from "./3-6C-SC-TH.server";
import { SERVER_CASE as CASE_3_10A_SC_WI } from "./3-10A-SC-WI.server";
import { SERVER_CASE as CASE_3_10A_SC_TH } from "./3-10A-SC-TH.server";
import { SERVER_CASE as CASE_3_10B_SC_WI } from "./3-10B-SC-WI.server";
import { SERVER_CASE as CASE_3_10B_SC_TH } from "./3-10B-SC-TH.server";
import { SERVER_CASE as CASE_3_10C_SC_WI } from "./3-10C-SC-WI.server";
import { SERVER_CASE as CASE_3_10C_SC_TH } from "./3-10C-SC-TH.server";
import { SERVER_CASE as CASE_3_11B_SC_WI } from "./3-11B-SC-WI.server";
import { SERVER_CASE as CASE_3_11B_SC_TH } from "./3-11B-SC-TH.server";
import { SERVER_CASE as CASE_3_12A_SC_WI } from "./3-12A-SC-WI.server";
import { SERVER_CASE as CASE_3_12A_SC_TH } from "./3-12A-SC-TH.server";
import { SERVER_CASE as CASE_3_12B_SC_WI } from "./3-12B-SC-WI.server";
import { SERVER_CASE as CASE_3_12B_SC_TH } from "./3-12B-SC-TH.server";
import { SERVER_CASE as CASE_3_12C_SC_WI } from "./3-12C-SC-WI.server";
import { SERVER_CASE as CASE_3_12C_SC_TH } from "./3-12C-SC-TH.server";
import { SERVER_CASE as CASE_3_12D_SC_WI } from "./3-12D-SC-WI.server";
import { SERVER_CASE as CASE_3_12D_SC_TH } from "./3-12D-SC-TH.server";
import { SERVER_CASE as CASE_3_13A_SC_WI } from "./3-13A-SC-WI.server";
import { SERVER_CASE as CASE_3_13A_SC_TH } from "./3-13A-SC-TH.server";
import { SERVER_CASE as CASE_3_13B_SC_WI } from "./3-13B-SC-WI.server";
import { SERVER_CASE as CASE_3_13B_SC_TH } from "./3-13B-SC-TH.server";
import { SERVER_CASE as CASE_3_7A_SC_WI } from "./3-7A-SC-WI.server";
import { SERVER_CASE as CASE_3_7A_SC_TH } from "./3-7A-SC-TH.server";
import { SERVER_CASE as CASE_3_7B_SC_WI } from "./3-7B-SC-WI.server";
import { SERVER_CASE as CASE_3_7B_SC_TH } from "./3-7B-SC-TH.server";
import { SERVER_CASE as CASE_3_8A_SC_WI } from "./3-8A-SC-WI.server";
import { SERVER_CASE as CASE_3_8A_SC_TH } from "./3-8A-SC-TH.server";
import { SERVER_CASE as CASE_3_8B_SC_WI } from "./3-8B-SC-WI.server";
import { SERVER_CASE as CASE_3_8B_SC_TH } from "./3-8B-SC-TH.server";
import { SERVER_CASE as CASE_3_9B_SC_WI } from "./3-9B-SC-WI.server";
import { SERVER_CASE as CASE_3_9B_SC_TH } from "./3-9B-SC-TH.server";
import { SERVER_CASE as CASE_3_7A_SC } from "./3-7A-SC.server";
import { SERVER_CASE as CASE_3_7B_SC } from "./3-7B-SC.server";
import { SERVER_CASE as CASE_3_8A_SC } from "./3-8A-SC.server";
import { SERVER_CASE as CASE_3_8B_SC } from "./3-8B-SC.server";
import { SERVER_CASE as CASE_3_9B_SC } from "./3-9B-SC.server";
import { SERVER_CASE as CASE_3_13A_SC } from "./3-13A-SC.server";
import { SERVER_CASE as CASE_3_13B_SC } from "./3-13B-SC.server";
import { SERVER_CASE as CASE_4_6B_SC } from "./4-6B-SC.server";
import { SERVER_CASE as CASE_4_6C_SC } from "./4-6C-SC.server";
import { SERVER_CASE as CASE_4_7_SC } from "./4-7-SC.server";
import { SERVER_CASE as CASE_4_8A_SC } from "./4-8A-SC.server";
import { SERVER_CASE as CASE_4_8B_SC } from "./4-8B-SC.server";
import { SERVER_CASE as CASE_4_8C_SC } from "./4-8C-SC.server";
import { SERVER_CASE as CASE_4_9A_SC } from "./4-9A-SC.server";
import { SERVER_CASE as CASE_4_9B_SC } from "./4-9B-SC.server";
import { SERVER_CASE as CASE_4_10A_SC } from "./4-10A-SC.server";
import { SERVER_CASE as CASE_4_11A_SC } from "./4-11A-SC.server";
import { SERVER_CASE as CASE_4_11B_SC } from "./4-11B-SC.server";
import { SERVER_CASE as CASE_4_11C_SC } from "./4-11C-SC.server";
import { SERVER_CASE as CASE_4_12A_SC } from "./4-12A-SC.server";
import { SERVER_CASE as CASE_4_12B_SC } from "./4-12B-SC.server";
import { SERVER_CASE as CASE_4_12C_SC } from "./4-12C-SC.server";
import { SERVER_CASE as CASE_4_13A_SC } from "./4-13A-SC.server";
import { SERVER_CASE as CASE_4_13B_SC } from "./4-13B-SC.server";
import { SERVER_CASE as CASE_5_6A_SC } from "./5-6A-SC.server";
import { SERVER_CASE as CASE_5_6B_SC } from "./5-6B-SC.server";
import { SERVER_CASE as CASE_5_6C_SC } from "./5-6C-SC.server";
import { SERVER_CASE as CASE_5_6D_SC } from "./5-6D-SC.server";
import { SERVER_CASE as CASE_5_7A_SC } from "./5-7A-SC.server";
import { SERVER_CASE as CASE_5_8A_SC } from "./5-8A-SC.server";
import { SERVER_CASE as CASE_5_8B_SC } from "./5-8B-SC.server";
import { SERVER_CASE as CASE_5_8C_SC } from "./5-8C-SC.server";
import { SERVER_CASE as CASE_5_9_SC } from "./5-9-SC.server";
import { SERVER_CASE as CASE_5_10A_SC } from "./5-10A-SC.server";
import { SERVER_CASE as CASE_5_10B_SC } from "./5-10B-SC.server";
import { SERVER_CASE as CASE_5_10C_SC } from "./5-10C-SC.server";
import { SERVER_CASE as CASE_5_11_SC } from "./5-11-SC.server";
import { SERVER_CASE as CASE_5_12A_SC } from "./5-12A-SC.server";
import { SERVER_CASE as CASE_5_12B_SC } from "./5-12B-SC.server";
import { SERVER_CASE as CASE_5_12C_SC } from "./5-12C-SC.server";
import { SERVER_CASE as CASE_5_13A_SC } from "./5-13A-SC.server";
import { SERVER_CASE as CASE_SS_3_2B_SC } from "./SS-3-2B-SC.server";
import { SERVER_CASE as CASE_SS_3_3A_SC } from "./SS-3-3A-SC.server";
import { SERVER_CASE as CASE_SS_3_3C_SC } from "./SS-3-3C-SC.server";
import { SERVER_CASE as CASE_SS_3_5B_SC } from "./SS-3-5B-SC.server";
import { SERVER_CASE as CASE_SS_3_6B_SC } from "./SS-3-6B-SC.server";
import { SERVER_CASE as CASE_SS_3_6C_SC } from "./SS-3-6C-SC.server";
import { SERVER_CASE as CASE_SS_3_7C_SC } from "./SS-3-7C-SC.server";
import { SERVER_CASE as CASE_SS_3_8A_SC } from "./SS-3-8A-SC.server";
import { SERVER_CASE as CASE_SS_3_9E_SC } from "./SS-3-9E-SC.server";
import { SERVER_CASE as CASE_SS_4_1B_SC } from "./SS-4-1B-SC.server";
import { SERVER_CASE as CASE_SS_4_2A_SC } from "./SS-4-2A-SC.server";
import { SERVER_CASE as CASE_SS_4_2C_SC } from "./SS-4-2C-SC.server";
import { SERVER_CASE as CASE_SS_4_3D_SC } from "./SS-4-3D-SC.server";
import { SERVER_CASE as CASE_SS_4_4B_SC } from "./SS-4-4B-SC.server";
import { SERVER_CASE as CASE_SS_4_6B_SC } from "./SS-4-6B-SC.server";
import { SERVER_CASE as CASE_SS_4_9A_SC } from "./SS-4-9A-SC.server";
import { SERVER_CASE as CASE_SS_4_11C_SC } from "./SS-4-11C-SC.server";
import { SERVER_CASE as CASE_SS_4_17B_SC } from "./SS-4-17B-SC.server";
import { SERVER_CASE as CASE_SS_5_2A_SC } from "./SS-5-2A-SC.server";
import { SERVER_CASE as CASE_SS_5_4A_SC } from "./SS-5-4A-SC.server";
import { SERVER_CASE as CASE_SS_5_4D_SC } from "./SS-5-4D-SC.server";
import { SERVER_CASE as CASE_SS_5_4E_SC } from "./SS-5-4E-SC.server";
import { SERVER_CASE as CASE_SS_5_7B_SC } from "./SS-5-7B-SC.server";
import { SERVER_CASE as CASE_SS_5_8B_SC } from "./SS-5-8B-SC.server";
import { SERVER_CASE as CASE_SS_5_13B_SC } from "./SS-5-13B-SC.server";
import { SERVER_CASE as CASE_SS_5_14B_SC } from "./SS-5-14B-SC.server";
import { SERVER_CASE as CASE_SS_5_15A_SC } from "./SS-5-15A-SC.server";

const REGISTRY = {
  "3.6A-SC": CASE_3_6A_SC,
  "4.10B-SC": CASE_4_10B_SC,
  "5.13B-SC": CASE_5_13B_SC,
  "SS.3.6A-SC": CASE_SS_3_6A_SC,
  "SS.4.3A-SC": CASE_SS_4_3A_SC,
  "SS.5.4C-SC": CASE_SS_5_4C_SC,
  "3.10A-SC": CASE_3_10A_SC,
  "3.10B-SC": CASE_3_10B_SC,
  "3.10C-SC": CASE_3_10C_SC,
  "3.11B-SC": CASE_3_11B_SC,
  "3.12A-SC": CASE_3_12A_SC,
  "3.12B-SC": CASE_3_12B_SC,
  "3.12C-SC": CASE_3_12C_SC,
  "3.12D-SC": CASE_3_12D_SC,
  "3.6B-SC": CASE_3_6B_SC,
  "3.6C-SC": CASE_3_6C_SC,
  "3.6A-SC-WI": CASE_3_6A_SC_WI,
  "3.6A-SC-TH": CASE_3_6A_SC_TH,
  "3.6B-SC-WI": CASE_3_6B_SC_WI,
  "3.6B-SC-TH": CASE_3_6B_SC_TH,
  "3.6C-SC-WI": CASE_3_6C_SC_WI,
  "3.6C-SC-TH": CASE_3_6C_SC_TH,
  "3.10A-SC-WI": CASE_3_10A_SC_WI,
  "3.10A-SC-TH": CASE_3_10A_SC_TH,
  "3.10B-SC-WI": CASE_3_10B_SC_WI,
  "3.10B-SC-TH": CASE_3_10B_SC_TH,
  "3.10C-SC-WI": CASE_3_10C_SC_WI,
  "3.10C-SC-TH": CASE_3_10C_SC_TH,
  "3.11B-SC-WI": CASE_3_11B_SC_WI,
  "3.11B-SC-TH": CASE_3_11B_SC_TH,
  "3.12A-SC-WI": CASE_3_12A_SC_WI,
  "3.12A-SC-TH": CASE_3_12A_SC_TH,
  "3.12B-SC-WI": CASE_3_12B_SC_WI,
  "3.12B-SC-TH": CASE_3_12B_SC_TH,
  "3.12C-SC-WI": CASE_3_12C_SC_WI,
  "3.12C-SC-TH": CASE_3_12C_SC_TH,
  "3.12D-SC-WI": CASE_3_12D_SC_WI,
  "3.12D-SC-TH": CASE_3_12D_SC_TH,
  "3.13A-SC-WI": CASE_3_13A_SC_WI,
  "3.13A-SC-TH": CASE_3_13A_SC_TH,
  "3.13B-SC-WI": CASE_3_13B_SC_WI,
  "3.13B-SC-TH": CASE_3_13B_SC_TH,
  "3.7A-SC-WI": CASE_3_7A_SC_WI,
  "3.7A-SC-TH": CASE_3_7A_SC_TH,
  "3.7B-SC-WI": CASE_3_7B_SC_WI,
  "3.7B-SC-TH": CASE_3_7B_SC_TH,
  "3.8A-SC-WI": CASE_3_8A_SC_WI,
  "3.8A-SC-TH": CASE_3_8A_SC_TH,
  "3.8B-SC-WI": CASE_3_8B_SC_WI,
  "3.8B-SC-TH": CASE_3_8B_SC_TH,
  "3.9B-SC-WI": CASE_3_9B_SC_WI,
  "3.9B-SC-TH": CASE_3_9B_SC_TH,
  "3.7A-SC": CASE_3_7A_SC,
  "3.7B-SC": CASE_3_7B_SC,
  "3.8A-SC": CASE_3_8A_SC,
  "3.8B-SC": CASE_3_8B_SC,
  "3.9B-SC": CASE_3_9B_SC,
  "3.13A-SC": CASE_3_13A_SC,
  "3.13B-SC": CASE_3_13B_SC,
  "4.6B-SC": CASE_4_6B_SC,
  "4.6C-SC": CASE_4_6C_SC,
  "4.7-SC": CASE_4_7_SC,
  "4.8A-SC": CASE_4_8A_SC,
  "4.8B-SC": CASE_4_8B_SC,
  "4.8C-SC": CASE_4_8C_SC,
  "4.9A-SC": CASE_4_9A_SC,
  "4.9B-SC": CASE_4_9B_SC,
  "4.10A-SC": CASE_4_10A_SC,
  "4.11A-SC": CASE_4_11A_SC,
  "4.11B-SC": CASE_4_11B_SC,
  "4.11C-SC": CASE_4_11C_SC,
  "4.12A-SC": CASE_4_12A_SC,
  "4.12B-SC": CASE_4_12B_SC,
  "4.12C-SC": CASE_4_12C_SC,
  "4.13A-SC": CASE_4_13A_SC,
  "4.13B-SC": CASE_4_13B_SC,
  "5.6A-SC": CASE_5_6A_SC,
  "5.6B-SC": CASE_5_6B_SC,
  "5.6C-SC": CASE_5_6C_SC,
  "5.6D-SC": CASE_5_6D_SC,
  "5.7A-SC": CASE_5_7A_SC,
  "5.8A-SC": CASE_5_8A_SC,
  "5.8B-SC": CASE_5_8B_SC,
  "5.8C-SC": CASE_5_8C_SC,
  "5.9-SC": CASE_5_9_SC,
  "5.10A-SC": CASE_5_10A_SC,
  "5.10B-SC": CASE_5_10B_SC,
  "5.10C-SC": CASE_5_10C_SC,
  "5.11-SC": CASE_5_11_SC,
  "5.12A-SC": CASE_5_12A_SC,
  "5.12B-SC": CASE_5_12B_SC,
  "5.12C-SC": CASE_5_12C_SC,
  "5.13A-SC": CASE_5_13A_SC,
  "SS.3.2B-SC": CASE_SS_3_2B_SC,
  "SS.3.3A-SC": CASE_SS_3_3A_SC,
  "SS.3.3C-SC": CASE_SS_3_3C_SC,
  "SS.3.5B-SC": CASE_SS_3_5B_SC,
  "SS.3.6B-SC": CASE_SS_3_6B_SC,
  "SS.3.6C-SC": CASE_SS_3_6C_SC,
  "SS.3.7C-SC": CASE_SS_3_7C_SC,
  "SS.3.8A-SC": CASE_SS_3_8A_SC,
  "SS.3.9E-SC": CASE_SS_3_9E_SC,
  "SS.4.1B-SC": CASE_SS_4_1B_SC,
  "SS.4.2A-SC": CASE_SS_4_2A_SC,
  "SS.4.2C-SC": CASE_SS_4_2C_SC,
  "SS.4.3D-SC": CASE_SS_4_3D_SC,
  "SS.4.4B-SC": CASE_SS_4_4B_SC,
  "SS.4.6B-SC": CASE_SS_4_6B_SC,
  "SS.4.9A-SC": CASE_SS_4_9A_SC,
  "SS.4.11C-SC": CASE_SS_4_11C_SC,
  "SS.4.17B-SC": CASE_SS_4_17B_SC,
  "SS.5.2A-SC": CASE_SS_5_2A_SC,
  "SS.5.4A-SC": CASE_SS_5_4A_SC,
  "SS.5.4D-SC": CASE_SS_5_4D_SC,
  "SS.5.4E-SC": CASE_SS_5_4E_SC,
  "SS.5.7B-SC": CASE_SS_5_7B_SC,
  "SS.5.8B-SC": CASE_SS_5_8B_SC,
  "SS.5.13B-SC": CASE_SS_5_13B_SC,
  "SS.5.14B-SC": CASE_SS_5_14B_SC,
  "SS.5.15A-SC": CASE_SS_5_15A_SC,
};

export function getSignalCheckServerCase(standard) {
  return REGISTRY[standard] || null;
}
